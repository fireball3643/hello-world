l = float(input("Side of Cube: "))

sa = 6 * (l * l)

print("Surface area: " , sa)
