radius = float(input("Radius = "))
diameter = radius * 2
circumference = diameter * 3.14
surfaceArea = 4 * 3.14 * radius * radius
volume = 4/3 * 3.14 * radius * radius * radius
print("Diameter: ", diameter)
print("Circumference: ", circumference)
print("Surface area : ", surfaceArea)
print("Volume ", volume)
