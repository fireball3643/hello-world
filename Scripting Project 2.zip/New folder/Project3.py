v = int(input("Number of new videos: "))
o = int(input("Number of oldies: "))
print("The total cost is","$",(v * 3.00) + (o * 2.00))
