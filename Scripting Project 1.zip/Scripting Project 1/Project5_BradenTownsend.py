base = int(input("Enter the base: "))
height = int(input("Enter the height: "))
area = .5 * base * height
print("The area is", area, "square units.")
