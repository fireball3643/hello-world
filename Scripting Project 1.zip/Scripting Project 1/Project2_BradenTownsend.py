name = "Braden Townsend"
address = "908 North Willey Road"
phone = "918-616-8472"
print(name, address, phone) 
