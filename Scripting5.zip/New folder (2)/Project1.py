(
    print('The triangle is equilateral') 
    if int(input('Length of side a: ')) 
       == int(input('Length of side b: ')) 
       == int(input('Length of side c: ')) 
    else print('The triangle is not equilateral')
)
