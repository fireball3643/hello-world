filename = input("Enter the file name: ")
inputfile = open(filename, 'r')
print('\n%-15s%-10s%-10s' % ('Name', 'Hours', 'Total Pay'))
for line in inputfile:
    dataList = line.split()
    name = str(dataList[0])
    hours = int(dataList[1])
    payRate = float(dataList[2])
    totalPay = hours *payRate 
print('%-15s%-10d%-10.2f' %(name,hours,totalPay))
print()
