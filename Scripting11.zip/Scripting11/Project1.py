from breezypythongui import EasyFrame
class TaxCalculator(EasyFrame):
    """Application window for the tax calculator."""
    def __init__(self):
        """Sets up the window and the widgets."""
        EasyFrame.__init__(self, title = "Tax Calculator")
        
        self.income_label = self.addLabel("Gross income", 0, 0)
        self.incomeField = self.addFloatField(0.0, 0, 1)

        self.dependents_label = self.addLabel("Dependents", 1, 0)
        self.depField = self.addIntegerField("0", 1, 1, width=10)
