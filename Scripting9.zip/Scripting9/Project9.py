from functools import reduce

fileName = input("Enter the input file name: ")
inputFile = open(fileName, 'r')

lyst = []
for line in inputFile:
    lyst.extend(line.split())

lyst = list(map(float, lyst))
print("lyst:",lyst)

sum = reduce(lambda x, y: x + y, lyst)

if len(lyst) == 0:
    average = 0
else:
    average = sum / len(lyst)
print("The average is", average)
